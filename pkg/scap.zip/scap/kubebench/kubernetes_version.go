package kubebench

import (
	"crypto/tls"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
)

func getKubeVersionFromRESTAPI() (string, error) {
	k8sVersionURL := getKubernetesURL()
	serviceaccount := "/var/run/secrets/kubernetes.io/serviceaccount"
	cacertfile := fmt.Sprintf("%s/ca.crt", serviceaccount)
	tokenfile := fmt.Sprintf("%s/token", serviceaccount)

	tlsCert, err := loadCertficate(cacertfile)
	if err != nil {
		return "", err
	}

	tb, err := ioutil.ReadFile(tokenfile)
	if err != nil {
		return "", err
	}
	token := strings.TrimSpace(string(tb))

	data, err := getWebData(k8sVersionURL, token, tlsCert)
	if err != nil {
		return "", err
	}

	k8sVersion, err := extractVersion(data)
	if err != nil {
		return "", err
	}
	return k8sVersion, nil
}

func extractVersion(data []byte) (string, error) {
	type versionResponse struct {
		Major        string
		Minor        string
		GitVersion   string
		GitCommit    string
		GitTreeState string
		BuildDate    string
		GoVersion    string
		Compiler     string
		Platform     string
	}

	vrObj := &versionResponse{}
	log.Info().Msgf("vd: %s\n", string(data))
	err := json.Unmarshal(data, vrObj)
	if err != nil {
		return "", err
	}
	log.Info().Msgf("vrObj: %#v\n", vrObj)

	// Some provides return the minor version like "15+"
	minor := strings.Replace(vrObj.Minor, "+", "", -1)
	ver := fmt.Sprintf("%s.%s", vrObj.Major, minor)
	return ver, nil
}

func getWebData(srvURL, token string, cacert *tls.Certificate) ([]byte, error) {
	log.Info().Msgf("getWebData srvURL: %s\n", srvURL)

	tlsConf := &tls.Config{
		Certificates:       []tls.Certificate{*cacert},
		InsecureSkipVerify: true,
	}
	tr := &http.Transport{
		TLSClientConfig: tlsConf,
	}
	client := &http.Client{Transport: tr}
	req, err := http.NewRequest(http.MethodGet, srvURL, nil)
	if err != nil {
		return nil, err
	}

	authToken := fmt.Sprintf("Bearer %s", token)
	log.Info().Msgf("getWebData AUTH TOKEN --[%q]--\n", authToken)
	req.Header.Set("Authorization", authToken)

	resp, err := client.Do(req)
	if err != nil {
		log.Info().Msgf("HTTP ERROR: %v\n", err)
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		log.Info().
			Msgf("URL:[%s], StatusCode:[%d] \n Headers: %#v\n", srvURL, resp.StatusCode, resp.Header)
		err = fmt.Errorf("URL:[%s], StatusCode:[%d]", srvURL, resp.StatusCode)
		return nil, err
	}

	return ioutil.ReadAll(resp.Body)
}

func loadCertficate(certFile string) (*tls.Certificate, error) {
	cacert, err := ioutil.ReadFile(certFile)
	if err != nil {
		return nil, err
	}

	var tlsCert tls.Certificate
	block, _ := pem.Decode(cacert)
	if block == nil {
		return nil, fmt.Errorf("unable to Decode certificate")
	}

	log.Info().Msg("Loading CA certificate")
	tlsCert.Certificate = append(tlsCert.Certificate, block.Bytes)
	return &tlsCert, nil
}

func getKubernetesURL() string {
	k8sVersionURL := "https://kubernetes.default.svc/version"

	// The following provides flexibility to use
	// K8S provided variables is situations where
	// hostNetwork: true
	if !isEmpty(os.Getenv("KUBE_BENCH_K8S_ENV")) {
		k8sHost := os.Getenv("KUBERNETES_SERVICE_HOST")
		k8sPort := os.Getenv("KUBERNETES_SERVICE_PORT_HTTPS")
		if !isEmpty(k8sHost) && !isEmpty(k8sPort) {
			return fmt.Sprintf("https://%s:%s/version", k8sHost, k8sPort)
		}

		log.Info().Msgf("KUBE_BENCH_K8S_ENV is set, but environment variables " +
			"KUBERNETES_SERVICE_HOST or KUBERNETES_SERVICE_PORT_HTTPS are not set")
	}

	return k8sVersionURL
}
